# RoxoPay Android + servidor online (projeto inicial)

Este projeto permite gerar um APK Android usando GitHub Actions pelo celular, sem instalar Android Studio. O app Android abre a versão web hospedada do RoxoPay. O servidor web precisa estar publicado em uma hospedagem Node.js com suporte a WebSockets/Socket.IO.

## Importante
- RoxoPay é um simulador independente. Não é o Nubank e não faz Pix real.
- O APK só vai conectar depois que você hospedar o servidor e trocar `https://COLOQUE-AQUI-SEU-SERVIDOR` pelo endereço HTTPS real.
- Não use senhas bancárias, CPF, chaves Pix reais nem dados financeiros verdadeiros.
- A versão do servidor inicial mantém dados em memória: reiniciar o servidor apaga contas e saldos. É apenas para testes.

## Parte A — publicar o servidor usando só o celular
1. No GitHub, crie uma conta (se ainda não tiver) e um repositório novo chamado `roxopay`.
2. Envie os arquivos da pasta `server/` deste ZIP para a raiz do repositório, ou crie um segundo repositório só para o servidor.
3. Publique `server/` em uma plataforma que rode Node.js e suporte WebSockets. Configure o comando de instalação `npm install` e o comando de inicialização `npm start`.
4. Copie o endereço HTTPS público gerado pela plataforma.
5. Teste esse endereço no navegador do celular. A página do RoxoPay deve abrir.

## Parte B — configurar o APK
1. Abra `android/app/src/main/java/com/roxopay/demo/MainActivity.java`.
2. Substitua `https://COLOQUE-AQUI-SEU-SERVIDOR` pelo endereço HTTPS real do servidor. Não coloque `/` no final.
3. Crie um repositório GitHub e envie todos os arquivos deste projeto, preservando as pastas.
4. Acesse a aba **Actions** do repositório e habilite GitHub Actions, se solicitado.
5. Abra o workflow **Build RoxoPay APK** e toque em **Run workflow**.
6. Espere o workflow terminar com o status verde.
7. Abra a execução concluída, desça até **Artifacts** e baixe `RoxoPay-debug-apk`.
8. Extraia o ZIP baixado no Android e instale `app-debug.apk`. Se o Android bloquear, permita temporariamente a instalação pelo navegador/gerenciador de arquivos usado para abrir o APK.

## Se não aparecer “Run workflow”
- Confirme que a pasta `.github/workflows/` e o arquivo `android-apk.yml` foram enviados.
- Entre em Actions e habilite workflows para o repositório.
- Espere alguns segundos e atualize a página.

## Testar transferências entre duas pessoas
1. As duas pessoas instalam o APK.
2. Ambas abrem o app, conectado ao mesmo servidor HTTPS.
3. Cada pessoa cria uma conta com nome diferente.
4. Cada uma pode adicionar saldo fictício de teste.
5. Uma abre “Fazer Pix”, informa o nome exato da outra conta e o valor, e confirma.
6. O saldo e o extrato devem atualizar nos dois celulares.

## Limitações de segurança
Este é um protótipo educacional, não um banco. Para uso público real seriam necessários banco de dados persistente, autenticação robusta, proteção contra abuso, rate limiting, backups, monitoramento e revisão de segurança. Não use esse projeto para simular comprovantes de pagamentos reais.
